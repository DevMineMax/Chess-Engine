package net.chessengine.util;

import net.chessengine.game.Board;
import net.chessengine.game.Square;
import net.chessengine.game.move.Direction;

public class BoardUtil {
    public static int getSquareID(int startID, Direction direction, int n){
        int o = 0;
        switch (direction){
            case UP:
                o = startID - 8 * n;
                break;

            case DOWN:
                o = startID + 8 * n;
                break;

            case RIGHT:
                o = startID + n;
                break;

            case LEFT:
                o = startID - n;
                break;

            case UP_LEFT:
                o = startID - 9 * n;
                break;

            case UP_RIGHT:
                o = startID - 7 * n;
                break;

            case DOWN_LEFT:
                o = startID + 7 * n;
                break;

            case DOWN_RIGHT:
                o = startID + 9 * n;
                break;
        }

        if(o > 63 || o < 0){
            o = -1;
        }

        return o;
    }

    public static int[] getCol(int id){
        int[] col = new int[8];
        if(id < 8){
           for(int i = 0; i < 8; i++){
               col[i] = getSquareID(id, Direction.DOWN, i);
           }
        }
        return col;
    }

    public static boolean isInCol(int col, int n){
            for(int colElements : getCol(col)){
                if(colElements == n){
                    return true;
                }
            }
        return false;
    }


    public static int getSquaresToBoardEdge(int start, Direction direction){


        int topLeftEdge = 0;
        int topRightEdge = 7;
        int bottomLeftEdge = 56;
        int bottomRightEdge = 63;

        int[] edgesRight = new int[]{
                15, 23, 31, 39, 47, 55, 63,
        };
        int[] edgesLeft = new int[]{
                8, 16, 24, 32, 40, 48, 56,
        };
        int[] edgesUp = new int[]{
                1, 2, 3, 4, 5, 6,
        };
        int[] edgesDown = new int[]{
                57,58,59,60,61,62,
        };


        int p = 1;
        int holder = 0;

        switch (direction){
            case UP:

                if(start == topLeftEdge || start == topRightEdge) return 0;

                for(int e : edgesUp){
                    if(start == e){
                        return 0;
                    }
                }

                for(int i = 0; i < 9; i++){
                    holder = getSquareID(start, direction, p);
                    for(int n : edgesUp){
                        if(holder == n){
                            return p;
                        }
                    }
                    if(holder == topRightEdge || holder == topLeftEdge) return p;

                    p++;
                }
                break;
            case DOWN:

                if(start == bottomLeftEdge || start == bottomRightEdge) return 0;

                for(int e : edgesDown){
                    if(start == e){
                        return 0;
                    }
                }

                for(int i = 0; i < 9; i++){
                    holder = getSquareID(start, direction, p);
                    for(int n : edgesDown){
                        if(holder == n){
                            return p;
                        }
                    }
                    if(holder == bottomLeftEdge || holder == bottomRightEdge) return p;

                    p++;
                }
                break;
            case RIGHT:

                if(start == bottomRightEdge || start == topRightEdge) return 0;

                for(int e : edgesRight){
                    if(start == e){
                        return 0;
                    }
                }
                for(int i = 0; i < 9; i++){
                    holder = getSquareID(start, direction, p);
                    for(int n : edgesRight){
                        if(holder == n){
                            return p;
                        }
                    }
                    if(holder == topRightEdge || holder == bottomRightEdge) return p;

                    p++;
                }
                break;
            case LEFT:
                if(start == bottomLeftEdge || start == topLeftEdge) return 0;

                for(int e : edgesLeft){
                    if(start == e){
                        return 0;
                    }
                }

                for(int i = 0; i < 9; i++){
                    holder = getSquareID(start, direction, p);
                    for(int n : edgesLeft){
                        if(holder == n){
                            return p;
                        }
                    }
                    if(holder == topLeftEdge || holder == bottomLeftEdge) return p;

                    p++;
                }
                break;

            case DOWN_LEFT:
                if(start == bottomLeftEdge) return 0;
                if(start == topLeftEdge) return 0;

                for(int s : edgesLeft){
                    if(start == s) return 0;
                }

                for(int i = 0; i < 9; i++){
                    holder = getSquareID(start, direction, p);
                    for(int n : edgesDown){
                        if(holder == n){
                            return p;
                        }
                    }
                    for(int n : edgesLeft){
                        if(holder == n){
                            return p;
                        }
                    }
                    if(holder == bottomLeftEdge) return p;

                    p++;
                }
                break;
            case UP_LEFT:
                if(start == topLeftEdge) return 0;
                if(start == bottomLeftEdge) return 0;

                for(int s : edgesLeft){
                    if(start == s) return 0;
                }


                for(int i = 0; i < 9; i++){
                    holder = getSquareID(start, direction, p);
                    for(int n : edgesUp){
                        if(holder == n){
                            return p;
                        }
                    }
                    for(int n : edgesLeft){
                        if(holder == n){
                            return p;
                        }
                    }

                    if(holder == topLeftEdge) return p;

                    p++;
                }
                break;
            case DOWN_RIGHT:
                if(start == bottomRightEdge) return 0;
                if(start == topRightEdge) return 0;

                for(int s : edgesRight){
                    if(start == s) return 0;
                }

                for(int i = 0; i < 9; i++){
                    holder = getSquareID(start, direction, p);
                    for(int n : edgesRight){
                        if(holder == n){
                            return p;
                        }
                    }
                    for(int n : edgesDown){
                        if(holder == n){
                            return p;
                        }
                    }
                    if(holder == bottomRightEdge) return p;

                    p++;
                }
                break;
            case UP_RIGHT:
                if(start == topLeftEdge) return 0;
                if(start == bottomRightEdge) return 0;

                for(int n : edgesRight){
                    if(start == n) return 0;
                }

                for(int n : edgesRight){
                    if(start == n) return 0;
                }

                for(int i = 0; i < 9; i++){
                    holder = getSquareID(start, direction, p);
                    for(int n : edgesUp){
                        if(holder == n){
                            return p;
                        }
                    }
                    for(int n : edgesRight){
                        if(holder == n){
                            return p;
                        }
                    }
                    if(holder == topRightEdge) return p;

                    p++;
                }
                break;

        }
        return -1;
    }
    public static Square idToSquare(int id){return Board.squares[id];}
    public static int squareToID(Square square){
        int p = 0;
        for(Square s : Board.squares) {
            if(s == square){
                return p;
            }
            p++;
        }
        return -1;
    }
}
