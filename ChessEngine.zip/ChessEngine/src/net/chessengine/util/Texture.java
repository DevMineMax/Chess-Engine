package net.chessengine.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Texture {

    private BufferedImage image;

    private int x,y,w,h;

    public Texture(String path){
        File file = new File(path);

        try {
            image = ImageIO.read(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        w = image.getWidth();
        h = image.getHeight();
    }

    public void render(Graphics2D g2){
        g2.drawImage(image, x,y,w,h,null);
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setWidth(int w) {
        this.w = w;
    }

    public void setHeight(int h) {
        this.h = h;
    }
}
