package net.chessengine.util;

public class FenTranslation {

    public int turn = 0; // 1 = WHITE 2 = BLACK;
    public int whiteCastle = 1; // 0 = NO; 1 = YES;
    public int blackCastle = 1; // 0 = NO; 1 = YES;
    public FenTranslation(String fen){
        String[] rows = fen.split("/");

    }

    public int[] getBoard(){
        return null;
    }



}
