package net.chessengine.window;

import net.chessengine.game.Board;
import net.chessengine.game.Square;
import net.chessengine.game.input.KeyInput;
import net.chessengine.game.input.MouseInput;
import net.chessengine.game.pieces.Pawn;

import javax.swing.*;
import java.awt.*;
import java.security.Key;

public class Window extends JFrame implements Runnable {

    private boolean running = true;
    public static Board board;
    private Image doubleBufferImage = null;
    private Graphics doubleBufferGraphics = null;
    private Graphics graphics;

    protected MouseInput mouseInput;
    protected KeyInput keyInput;

    public Window(int w, int h, String t){
        mouseInput = new MouseInput();
        keyInput = new KeyInput();

        this.setSize(w, h);
        this.setTitle(t);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);
        this.addMouseListener(mouseInput);
        this.addMouseMotionListener(mouseInput);
        this.addKeyListener(keyInput);

        init();
    }


    public void init(){
        this.graphics = this.getGraphics();
        board = Board.get();
    }

    public void update(){
        board.update();
        render(graphics);
    }

    public void render(Graphics g){
        if(doubleBufferImage == null){
            doubleBufferImage = createImage(getWidth(), getHeight());
            doubleBufferGraphics = doubleBufferImage.getGraphics();
        }
        renderOffScreen(doubleBufferGraphics);
        g.drawImage(doubleBufferImage, 0, 0, null);
        doubleBufferImage = null;
    }

    public void renderOffScreen(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(new Color(36, 56, 35));
        g2.fillRect(0, 0, getWidth(), getHeight());
        board.render(g2);
    }

    @Override
    public void run() {
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int updates = 0;
        int frames = 0;
        while(running){
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while(delta >= 1){
                update();
                updates++;
                delta--;
            }
            frames++;

            if(System.currentTimeMillis() - timer > 1000){
                timer += 1000;
               // System.out.println("FPS: " + frames + " TICKS: " + updates);
                frames = 0;
                updates = 0;
            }
        }
    }
}
