package net.chessengine.game.pieces;

import net.chessengine.game.Square;
import net.chessengine.game.move.Direction;
import net.chessengine.game.move.Move;
import net.chessengine.util.BoardUtil;
import net.chessengine.util.Texture;

import java.util.ArrayList;
import java.util.Arrays;

public class Knight extends Piece {

    public static int id = 4;
    public Knight(int color, int square, int[] board) {
        super(300, color == 1 ? new Texture("assets/WhiteKnight.png") : new Texture("assets/BlackKnight.png"), color , square, board);
        this.legalMoves = new ArrayList<>();
    }

    private ArrayList<Integer> possibleMoves = new ArrayList<>();
    @Override
    public void generateMoves() {


       if(BoardUtil.getSquaresToBoardEdge(square, Direction.RIGHT) >= 2){
           if(BoardUtil.getSquaresToBoardEdge(square, Direction.UP) >= 1){
               possibleMoves.add(new Move(square, BoardUtil.getSquareID(square, Direction.UP, 1) + 2).targetSquare); // 1 Up, 2 Right;
           }
           if(BoardUtil.getSquaresToBoardEdge(square, Direction.DOWN) >= 1){
               possibleMoves.add(new Move(square, BoardUtil.getSquareID(square, Direction.DOWN, 1) + 2).targetSquare);// 1 Down, 2 Right;
           }
       }
        if(BoardUtil.getSquaresToBoardEdge(square, Direction.LEFT) >= 2){
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.UP) >= 1){
                possibleMoves.add(new Move(square, BoardUtil.getSquareID(square, Direction.UP, 1) - 2).targetSquare); // 1 Up, 2 Left;
            }
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.DOWN) >= 1){
                possibleMoves.add(new Move(square, BoardUtil.getSquareID(square, Direction.DOWN, 1) - 2).targetSquare);// 1 Down, 2 Left;
            }
        }
        if(BoardUtil.getSquaresToBoardEdge(square, Direction.UP) >= 2){
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.LEFT) >= 1){
                possibleMoves.add(new Move(square, BoardUtil.getSquareID(square, Direction.LEFT, 1) - 8 * 2).targetSquare); // 2 Up, 1 Left;
            }
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.RIGHT) >= 1){
                possibleMoves.add(new Move(square, BoardUtil.getSquareID(square, Direction.RIGHT, 1) - 8 * 2).targetSquare);// 2 Down, 1 Left;
            }
        }
        if(BoardUtil.getSquaresToBoardEdge(square, Direction.DOWN) >= 2){
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.LEFT) >= 1){
                possibleMoves.add(new Move(square, BoardUtil.getSquareID(square, Direction.LEFT, 1) + 8 * 2).targetSquare); // 2 Up, 1 Left;
            }
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.RIGHT) >= 1){
                possibleMoves.add(new Move(square, BoardUtil.getSquareID(square, Direction.RIGHT, 1) + 8 * 2).targetSquare);// 2 Down, 1 Left;
            }
        }




        for (int moves : possibleMoves) {
            if (moves >= 0 && moves < 64) {
                    if(color == 1){
                        if(board[moves] <= 0){
                            legalMoves.add(new Move(square, moves));
                            attackedSquaresWhite.add(moves);
                        }
                    }else{
                        if(board[moves] >= 0){
                            legalMoves.add(new Move(square, moves));
                            attackedSquaresBlack.add(moves);
                        }
                    }
            }
        }
    }
    @Override
    public void markLegalMoves() {
        for(Move move : legalMoves){
            BoardUtil.idToSquare(move.targetSquare).mark();
        }
    }
    @Override
    public void unmarkLegalMoves() {
        for(Move move : legalMoves){
            BoardUtil.idToSquare(move.targetSquare).unmark();
        }
    }


}

