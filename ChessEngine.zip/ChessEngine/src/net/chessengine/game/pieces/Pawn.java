package net.chessengine.game.pieces;

import net.chessengine.game.Square;
import net.chessengine.game.move.Direction;
import net.chessengine.game.move.Move;
import net.chessengine.util.BoardUtil;
import net.chessengine.util.Texture;
import net.chessengine.window.Window;

import java.util.ArrayList;

public class Pawn extends Piece {
    public static int id = 2;
    private ArrayList<Integer> possibleMovesWhite = new ArrayList<>();
    private ArrayList<Integer> possibleMovesBlack = new ArrayList<>();
    public int moveCount = 0;

    public Pawn(int color, int square, int[] board) {
        super(100, color == 1 ? new Texture("assets/WhitePawn.png") : new Texture("assets/BlackPawn.png"), color, square, board);
        legalMoves = new ArrayList<>();
    }


    @Override
    public void generateMoves() {
        legalMoves.addAll(generatePawnMoves(square, color));

        int attpos1 = BoardUtil.getSquareID(square, Direction.UP, 1) - 1; // top left from pawn;
        int attpos2 = BoardUtil.getSquareID(square, Direction.UP, 1) + 1;// top right from pawn;
        int attpos3 = BoardUtil.getSquareID(square, Direction.DOWN, 1) - 1; // down left from pawn;
        int attpos4 = BoardUtil.getSquareID(square, Direction.DOWN, 1) + 1;// down right from pawn;
        if(color == 1){
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.RIGHT) >= 1){
                attackedSquaresWhite.add(attpos2);
            }
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.LEFT) >= 1){
                attackedSquaresWhite.add(attpos1);
            }
        }
        if(color == 2){
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.RIGHT) >= 1){
                attackedSquaresWhite.add(attpos4);
            }
            if(BoardUtil.getSquaresToBoardEdge(square, Direction.LEFT) >= 1){
                attackedSquaresWhite.add(attpos3);
            }
        }

    }

    @Override
    public void markLegalMoves() {
        for (Move move : legalMoves) {
            BoardUtil.idToSquare(move.targetSquare).mark();
        }
    }

    @Override
    public void unmarkLegalMoves() {
        for (Move move : legalMoves) {
            BoardUtil.idToSquare(move.targetSquare).unmark();
        }
    }

}
