package net.chessengine.game.pieces;

import net.chessengine.game.Square;
import net.chessengine.game.move.Direction;
import net.chessengine.game.move.Move;
import net.chessengine.util.BoardUtil;
import net.chessengine.util.Texture;

import java.util.ArrayList;

public class Bishop  extends Piece {

    public static int id = 5;
    public Bishop(int color, int square, int[] board) {
        super(300, color == 1 ? new Texture("assets/WhiteBishop.png") : new Texture("assets/BlackBishop.png"), color, square, board);
        this.legalMoves = new ArrayList<>();
    }

    @Override
    public void generateMoves() {


        legalMoves.addAll(generateSlidingMoves(square, Direction.UP_RIGHT, color));
        legalMoves.addAll(generateSlidingMoves(square, Direction.DOWN_LEFT, color));
        legalMoves.addAll(generateSlidingMoves(square, Direction.UP_LEFT, color));
        legalMoves.addAll(generateSlidingMoves(square, Direction.DOWN_RIGHT, color));

        if(color == 1){
            for(Move move : legalMoves){
                attackedSquaresWhite.add(move.targetSquare);
            }
        }
        if(color == 2){
            for(Move move : legalMoves){
                attackedSquaresBlack.add(move.targetSquare);
            }
        }

    }

    @Override
    public void markLegalMoves() {
        for(Move move : legalMoves){
            BoardUtil.idToSquare(move.targetSquare).mark();
        }
    }
    @Override
    public void unmarkLegalMoves() {
        for(Move move : legalMoves){
            BoardUtil.idToSquare(move.targetSquare).unmark();
        }
    }


}
