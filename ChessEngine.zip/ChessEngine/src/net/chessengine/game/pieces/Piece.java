package net.chessengine.game.pieces;

import net.chessengine.game.Square;
import net.chessengine.game.move.Direction;
import net.chessengine.game.move.Move;
import net.chessengine.util.BoardUtil;
import net.chessengine.util.Texture;
import net.chessengine.window.Window;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public abstract class Piece {


    public int worth;
    public int moveCount = 0;
    public Texture texture;
    public int square;
    public int color;

    public int[] board;
    public ArrayList<Move> legalMoves;
    public ArrayList<Integer> attackedSquaresWhite = new ArrayList<>();
    public ArrayList<Integer> attackedSquaresBlack = new ArrayList<>();
    public Piece(int worth, Texture texture, int color, int square, int[] board) {
        this.worth = worth;
        this.color = color;
        this.texture = texture;
        this.square = square;
        this.board = board;
    }

    public void update() {
        texture.setX(BoardUtil.idToSquare(square).getX());
        texture.setY(BoardUtil.idToSquare(square).getY());
    }

    public abstract void generateMoves();


    public abstract void markLegalMoves();

    public abstract void unmarkLegalMoves();


    public void render(Graphics2D g2) {
        texture.render(g2);
    }

    public ArrayList<Move> generateSlidingMoves(int start, Direction direction, int color) {
        ArrayList<Move> moves = new ArrayList<>();

        int distance = BoardUtil.getSquaresToBoardEdge(start, direction);
        for (int i = 0; i < distance; i++) {
            int d = BoardUtil.getSquareID(square, direction, i + 1);
            if (color == 1) {
                if (board[d] < 0) {
                    legalMoves.add(new Move(square, d));
                    break;
                }
                if (board[d] > 0) {
                    break;
                }
                legalMoves.add(new Move(square, d));
            }
            if (color == 2) {
                if (board[d] > 0) {
                    legalMoves.add(new Move(square, d));
                    break;
                }
                if (board[d] < 0) {
                    break;
                }
                legalMoves.add(new Move(square, d));
            }
        }
        return moves;
    }

    public ArrayList<Move> generatePawnMoves(int start, int color) {
        ArrayList<Move> moves = new ArrayList<>();

        int pos1 = 0, pos2 = 0, attpos1 = 0, attpos2 = 0;
        if(color == 1){
            pos1 = BoardUtil.getSquareID(start, Direction.UP, 1);
            pos2 = BoardUtil.getSquareID(start, Direction.UP, 2);
            attpos1 = BoardUtil.getSquareID(start, Direction.UP, 1) - 1; // top left from pawn;
            attpos2 = BoardUtil.getSquareID(start, Direction.UP, 1) + 1;// top right from pawn;

            if(pos1 != -1){
                if(board[pos1] == 0){
                    moves.add(new Move(start, pos1));
                }

                if(square > 47 && square < 56){
                    if(board[pos1] == 0){
                        if(board[pos2] == 0){
                            moves.add(new Move(start, pos2));
                        }
                    }
                }
            }else{
                // Promotion.
            }
            if(attpos1 > 0){
                if(board[attpos1] < 0){
                    legalMoves.add(new Move(square, attpos1));
                }
            }
           if(attpos2 > 0){
               if(board[attpos2] < 0){
                   legalMoves.add(new Move(square, attpos2));
               }
           }


        }else  if(color == 2){
            pos1 = BoardUtil.getSquareID(start, Direction.DOWN, 1);
            pos2 = BoardUtil.getSquareID(start, Direction.DOWN, 2);
            attpos1 = BoardUtil.getSquareID(start, Direction.DOWN, 1) - 1; // down left from pawn;
            attpos2 = BoardUtil.getSquareID(start, Direction.DOWN, 1) + 1;// down right from pawn;

            if(pos1 != -1){
                if(board[pos1] == 0){
                    moves.add(new Move(start, pos1));
                }
                if(square > 7 && square < 16){
                    if(board[pos1] == 0){
                        if(board[pos2] == 0){
                            moves.add(new Move(start, pos2));
                        }
                    }
                }
            }else{
                // Promotion.
            }

            if(attpos1 > 0){
                if(board[attpos1] > 0){
                    legalMoves.add(new Move(square, attpos1));
                }
            }
            if(attpos2 > 0){
                if(board[attpos2] > 0){
                    legalMoves.add(new Move(square, attpos2));
                }
            }

        }

        return moves;
    }


}
