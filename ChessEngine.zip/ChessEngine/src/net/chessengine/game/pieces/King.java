package net.chessengine.game.pieces;

import net.chessengine.game.Square;
import net.chessengine.game.move.Direction;
import net.chessengine.game.move.Move;
import net.chessengine.util.BoardUtil;
import net.chessengine.util.Texture;

import java.util.ArrayList;

public class King extends Piece {

    public static int id = 7;
    public King(int color, int square, int[] board) {
        super(10000, color == 1 ? new Texture("assets/WhiteKing.png") : new Texture("assets/BlackKing.png"), color, square, board);
        legalMoves = new ArrayList<>();
    }

    private ArrayList<Integer> possibleMoves = new ArrayList<>();
    @Override
    public void generateMoves() {
     possibleMoves = new ArrayList<>();

        if(BoardUtil.getSquaresToBoardEdge(square, Direction.RIGHT) >= 1){
         possibleMoves.add(BoardUtil.getSquareID(square, Direction.RIGHT, 1));
            possibleMoves.add(BoardUtil.getSquareID(square, Direction.UP_RIGHT, 1));
            possibleMoves.add(BoardUtil.getSquareID(square, Direction.DOWN_RIGHT, 1));
        }else{

        }
        if(BoardUtil.getSquaresToBoardEdge(square, Direction.LEFT) >= 1){
            possibleMoves.add(BoardUtil.getSquareID(square, Direction.LEFT, 1));
            possibleMoves.add(BoardUtil.getSquareID(square, Direction.UP_LEFT, 1));
            possibleMoves.add(BoardUtil.getSquareID(square, Direction.DOWN_LEFT, 1));
        }
        if(BoardUtil.getSquaresToBoardEdge(square, Direction.UP) >= 1){
            possibleMoves.add(BoardUtil.getSquareID(square, Direction.UP, 1));
        }
        if(BoardUtil.getSquaresToBoardEdge(square, Direction.DOWN) >= 1){
            possibleMoves.add(BoardUtil.getSquareID(square, Direction.DOWN, 1));
        }


        for(int move : possibleMoves){
            // First Check; (Looks if there are white pieces);
            if(color == 1){
                if(move == -1) continue;
                  if(board[move] <= 0){
                       legalMoves.add(new Move(square, move));
                       attackedSquaresWhite.add(move);
                   }
            }else{
                if(move == -1) continue;
                if(board[move] >= 0){
                    legalMoves.add(new Move(square, move));
                    attackedSquaresBlack.add(move);
                }
            }

        }
    }

    @Override
    public void markLegalMoves() {
        for(Move move : legalMoves){
            BoardUtil.idToSquare(move.targetSquare).mark();
        }
    }
    @Override
    public void unmarkLegalMoves() {
        for(Move move : legalMoves){
            BoardUtil.idToSquare(move.targetSquare).unmark();
        }
    }


}

