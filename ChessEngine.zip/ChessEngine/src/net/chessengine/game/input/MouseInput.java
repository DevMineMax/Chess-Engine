package net.chessengine.game.input;

import net.chessengine.game.Square;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MouseInput extends MouseAdapter {

    public static float x,y;
    public static boolean pressingR, pressingL;

    @Override
    public void mouseMoved(MouseEvent e) {
        x = e.getX();
        y = e.getY();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(e.getButton() == 1){
            pressingL = true;
        }else if(e.getButton() == 3){
            pressingR = true;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getButton() == 1){
            pressingL = false;
        }else if(e.getButton() == 3){
            pressingR = false;
        }
    }
    public static boolean isHoveringSquare(Square square){
        Rectangle rectangle = new Rectangle(square.getX(),square.getY(), square.getWidth(),square.getHeight());
        Rectangle rectangle2 = new Rectangle((int) x, (int) y,1,1);
        return rectangle2.intersects(rectangle);
    }


}
