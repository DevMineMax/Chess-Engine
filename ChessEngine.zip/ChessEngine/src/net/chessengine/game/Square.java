package net.chessengine.game;

import java.awt.*;

public class Square {

    private int color;
    private int width, height;
    private int x, y;

    public int idX,idY;

    private boolean moveShowed = false;
    private boolean isMarked = false;
    private boolean isAttMarked = false;
    public Square(int color, int x, int y, int width, int height, int idX, int idY){ // 1 = White, 2 = Black;
        this.color = color;
        this.x = x;
        this.y = y;
        this.idX = idX;
        this.idY = idY;
        this.width = width;
        this.height = height;
    }


    public void render(Graphics2D g2){
        Color c = color == 1 ? new Color(184, 199, 183) : new Color(76, 135, 72); // First color is the color for light squares; Second color is the color for dark squares;
        Color cm = color == 1 ? new Color(214, 83, 81) : new Color(179, 62, 61); // First color is the color for light squares; Second color is the color for dark squares;
        Color cm2 = color == 1 ? new Color(94, 186, 204) : new Color(40, 117, 133); // First color is the color for light squares; Second color is the color for dark squares;

        if(!isMarked && !isAttMarked){
            g2.setColor(c);
        }else if(isAttMarked){
            g2.setColor(cm2);
        }
        if(isMarked && !isAttMarked){
            g2.setColor(cm);
        }


        g2.fillRect(x,y,width,height);

        if(moveShowed){
            g2.setColor(new Color(0,0,0, 66));
            g2.fillOval(x+25,y+25,width/4,height/4);
        }

    }

    public void mark(){
        isMarked = true;
    }
    public void unmark(){
        isMarked = false;
    }


    public void attackMark(){
        isAttMarked = true;
    }
    public void attackUnMark(){
        isMarked = false;
    }

    public boolean isMarked() {
        return isMarked;
    }

    public void showMove(){
        moveShowed = true;
    }
    public void hideMove(){
        moveShowed = false;
    }


    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    @Override
    public String toString() {
        return "Square on Board: X: " + idX + ", Y: " + idY;
    }
}
