package net.chessengine.game.move;

public enum Direction {

    RIGHT, LEFT, UP, DOWN, UP_LEFT, UP_RIGHT, DOWN_LEFT, DOWN_RIGHT;

}
