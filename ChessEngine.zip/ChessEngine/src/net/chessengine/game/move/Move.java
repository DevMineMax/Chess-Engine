package net.chessengine.game.move;

public class Move {

    public int startSquareSave;
    public int startSquare, targetSquare;
    public int piece;

    public Move(int startSquare, int targetSquare){
        this.startSquare = startSquare;
        this.startSquareSave = startSquare;
        this.targetSquare = targetSquare;
    }

    public void move(int[] board){
        board[targetSquare] = board[startSquare];
        board[startSquare] = 0;
    }

    @Override
    public String toString() {
        return startSquare + " -> " + targetSquare;
    }
}
