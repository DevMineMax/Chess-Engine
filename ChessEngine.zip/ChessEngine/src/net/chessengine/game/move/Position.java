package net.chessengine.game.move;

import net.chessengine.game.pieces.King;
import net.chessengine.game.pieces.Pawn;
import net.chessengine.game.pieces.Piece;

import java.util.ArrayList;
import java.util.Scanner;

public class Position {

    public int[] square;
    public int moveNumber;

    public King whiteKing = null;
    public King blackKing = null;

    public ArrayList<Move> pseudoLegalMoves = new ArrayList<>();
    public ArrayList<Integer> attackedSquaresWhite = new ArrayList<>();
    public ArrayList<Integer> attackedSquaresBlack = new ArrayList<>();

    public ArrayList<Piece> pieces = new ArrayList<>();


    public boolean whiteAllowedCastle = true;
    public boolean blackAllowedCastle = true;

    public boolean checkMate = false;
    public boolean staleMate = false;

    public int turn; // 1 = White, 2 = Black;

    public Position(int moveNumber, int[] square){
        generatePseudoLegaMoves();
        this.square = square;
        turn = moveNumber % 2 == 0 ? 1 : 2;
    }



    public void generatePseudoLegaMoves(){
        for(Piece piece : pieces){
            if(piece.color == turn){
                piece.generateMoves();
                pseudoLegalMoves.addAll(piece.legalMoves); // Add the generated moves from the pieces into one list;
            }

            if(piece.color == 1){ // Check the piece color;
                attackedSquaresWhite.addAll(piece.attackedSquaresWhite); // Put the from white pieces attacked squares into a list;

            }else
                if(piece.color == 2){
                attackedSquaresBlack.addAll(piece.attackedSquaresBlack); // Put the from black pieces attacked squares into a list;
            }
        }
    }



}
