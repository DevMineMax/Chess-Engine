package net.chessengine.game.test;

import net.chessengine.game.move.Move;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class Perft {
    private int depth;
    private int[] board;
    private ArrayList<Move> moves;
    public Perft(int depth, ArrayList<Move> moves, int[] board){
        this.depth = depth;
        this.moves = moves;
        this.board = board;
        Perft();
    }

    public double Perft(){
        double nodes = 0;

        if(depth <= 0) return 0;



        new Perft(depth - 1, moves, board);

        return nodes;
    }

}
