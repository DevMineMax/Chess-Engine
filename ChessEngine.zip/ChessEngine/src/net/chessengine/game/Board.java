package net.chessengine.game;

import net.chessengine.game.input.KeyInput;
import net.chessengine.game.input.MouseInput;
import net.chessengine.game.move.Direction;
import net.chessengine.game.move.Move;
import net.chessengine.game.move.Position;
import net.chessengine.game.pieces.*;
import net.chessengine.game.test.Perft;
import net.chessengine.util.BoardUtil;
import net.chessengine.util.FenTranslation;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Random;

public class Board {

    // Board creation;
    public int width, height;
    public int squareWidth, squareHeight;


    public static Square[] squares;
    private int[] board;
    private Position currentPosition;
    private static Board instance;

    private Board(int width, int height, int squareWidth, int squareHeight) {

          /* 0 = empty, 1 = white pawn, 2 = white knight, 3 = white bishop, 4 white rook, 5 = white queen, 6 = white king,
   -1 = black pawn, -2 = black knight, -3 = black bishop, -4 black rook, -5 = black queen, -6 = black king;
    */
      /*  board = new int[]{
                -4, -2, -3, -5, -6, -3, -2, -4,
                -1, -1, -1, -1, -1, -1, -1, -1,
                0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0,
                1, 1, 1, 1, 1, 1, 1, 1,
                4, 2, 3, 5, 6, 3, 2, 4,
        };
*/
     board = new int[]{
             0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 5, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0,
        };


        this.width = width;
        this.height = height;
        this.squareWidth = squareWidth;
        this.squareHeight = squareHeight;
        squares = new Square[64]; // 64;
        createBoard();

        currentPosition = new Position(0, board);
        updatePosition();

        System.out.println(currentPosition.pseudoLegalMoves.size());
    }

    public void updatePosition() {
        currentPosition.pieces.addAll(createPiecesFromArray(currentPosition.square));
        currentPosition.generatePseudoLegaMoves();
        currentPosition.pieces.addAll(createPiecesFromArray(currentPosition.square));


        for(Move s : currentPosition.pseudoLegalMoves){
            int square = s.targetSquare;
            squares[square].mark();
        }
    }

    public static Board get() {
        if (instance == null) {
            Board.instance = new Board(8, 8, 60, 60);
        }
        return instance;
    }

    public ArrayList<Piece> createPiecesFromArray(int[] board) {
        ArrayList<Piece> pieces = new ArrayList<>();
        currentPosition.pieces.clear();
        for (int i = 0; i < board.length; i++) {
            switch (board[i]) {
                case 1:
                    pieces.add(new Pawn(1, i, board));
                    break;
                case -1:
                    pieces.add(new Pawn(2, i, board));
                    break;
                case 2:
                    pieces.add(new Knight(1, i, board));
                    break;
                case -2:
                    pieces.add(new Knight(2, i, board));
                    break;
                case 3:
                    pieces.add(new Bishop(1, i, board));
                    break;
                case -3:
                    pieces.add(new Bishop(2, i, board));
                    break;
                case 4:
                    pieces.add(new Rook(1, i, board));
                    break;
                case -4:
                    pieces.add(new Rook(2, i, board));
                    break;
                case 5:
                    pieces.add(new Queen(1, i, board));
                    break;
                case -5:
                    pieces.add(new Queen(2, i, board));
                    break;
                case 6:
                    currentPosition.whiteKing = new King(1, i, board);
                    pieces.add( currentPosition.whiteKing);
                    break;
                case -6:
                    currentPosition.blackKing = new King(1, i, board);
                    pieces.add(currentPosition.blackKing);
                    break;
            }
        }
        return pieces;
    }

    int p = 0;
    public void update() {

        if(KeyInput.isPressed(KeyEvent.VK_N) && p == 0){

            p = 1;
        }

        if(!KeyInput.isPressed(KeyEvent.VK_N) && p == 1){
            p = 0;
        }

        for (Piece p : currentPosition.pieces) {
            p.update();
        } // Update all pieces;
    }

    public void render(Graphics2D g2) {
        for (int i = 0; i < squares.length; i++) {
            squares[i].render(g2);
        }

        for (Piece p : currentPosition.pieces) {
            p.render(g2);
        }

    } // Render the pieces and the board;

    // Creates the Squares and put them into the array;
    private void createBoard() {
        int y = 1;
        int x = 1;

        for (int i = 0; i < squares.length; i++) {
            if (y % 2 != 1) {
                int color = x % 2 != 1 ? 2 : 1;
                squares[i] = new Square(color, 100 + squareWidth * x, 100 + squareHeight * y, squareWidth, squareHeight, x, y);
            } else {
                int color = x % 2 == 1 ? 2 : 1;
                squares[i] = new Square(color, 100 + squareWidth * x, 100 + squareHeight * y, squareWidth, squareHeight, x, y);
            }
            if (x >= 8) {
                y++;
                x = 0;
            }
            x++;
        }

    } // Create the Board;


}

