package net.chessengine.main;

import net.chessengine.window.Window;

public class Main {
    public static void main(String[] args) {
        Thread thread = new Thread(new Window(1020, 720, "Chess Engine"));
        thread.start();


  //      int color = (x * y) % 2 == 1 ? 1 : 2;


    }
}